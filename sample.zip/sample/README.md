# GIS-OER sample data(sample)

このデータは、ErthExplorerからダウンローしたLandsat8のデータを編集・使用しています。 "The source data were downloaded from USGS's ErthExplorer, (https://earthexplorer.usgs.gov/). Landsat 8 data courtesy of the U.S. Geological Survey."
