# GIS-OER sample data(Tokyo)

|Name|Data_type_S|EPSG|Source|
|---|---|---|---|
|rail_S|ESRI shapefile|6668|OpenStreetMap|
|subway_S|ESRI shapefile|6668|OpenStreetMap|
|station_S|ESRI shapefile|6668|OpenStreetMap|
|river_S|ESRI shapefile|6668|OpenStreetMap|
|post_office_S|ESRI shapefile|6668|OpenStreetMap|
|cvs_jgd2011_S|ESRI shapefile|6668|OpenStreetMap|
|tokyo_23ku_S|ESRI shapefile|6668|OpenStreetMap|
|post_office|CSV|4326|OpenStreetMap|
|post_office_S|ESRI shapefile|6668|OpenStreetMap|
|tokyo_srtm_S|Geotiff|6668|SRTM 1 Arc-Second Global|
|gisoer_tiles|XML||https://github.com/MIERUNE/mierune-qgis |
