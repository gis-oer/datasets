# GIS-OER sample data(fuji_task)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|fuji_2011|GeoTIFF|6668|SRTM 1 Arc-Second Global|
