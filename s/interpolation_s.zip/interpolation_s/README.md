# GIS-OER sample data(interpolation)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|fuji|GeoTIFF|6676|SRTM 1 Arc-Second Global|
|elevation_s|Shapefile|6668|SRTM 1 Arc-Second Global|
|river_s|Shapefile|6668|SRTM 1 Arc-Second Global|
