# GIS-OER sample data(Osaka)

|Name|Data_type_s|EPSG|Source|
|---|---|---|---|
|kindergarten_s|ESRI shapefile|6668|大阪市オープンデータ（施設情報ポイントデータ（学校・保育所）(令和元年10月1日時点)）|
|school_s|ESRI shapefile|6668|大阪市オープンデータ（施設情報ポイントデータ（学校・保育所）(令和元年10月1日時点)）|
|river_s|ESRI shapefile|6668|OpenStreetMap|
|yodo_river_s|ESRI shapefile|6668|OpenStreetMap|
|osaka_s_s|ESRI shapefile|6668|OpenStreetMap|
|osaka|Geotiff|6668|SRTM 1 Arc-Second Global|
|elevation_s|ESRI shapefile|6668|SRTM 1 Arc-Second Global|
|h29_population|csv||行政区別・男女別・5歳階級別人口及び世帯数(平成29年9月末日現在)|
|h31_chika_s|ESRI shapefile|6668|地価公示（基準日平成31年1月1日）|
