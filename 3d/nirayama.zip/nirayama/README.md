# データの出典

|Name|Data Source|
|---|---|
|30-XXX01-01-00-01|[静岡県ＰＣＤＢ　CC-BY](https://pointcloud.pref.shizuoka.jp/lasmap/ankenmap?ankenno=30XXX01010001)|
