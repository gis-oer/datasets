# echizen
このデータは、[越前市オープンデータ](http://www.city.echizen.lg.jp/office/010/021/open-data-echizen.html) 越前市防災安全課　一次避難場所（風水害）、浸水想定区域（風水害）のデータを利用し、作成した。
