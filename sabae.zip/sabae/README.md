# GIS-OER sample data(Sabae)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|sabae_007|jpeg||Data City Sabae（古地図007）|
|sabae_aed_jgd2000|ESRI shapefile|4612|Data City Sabae（AED）|
|sabae_aed_tokyo|ESRI shapefile|4301|Data City Sabae（AED）|
|sabae_store|CSV||Data City Sabae（店舗）|
|sabae_aed_jgd2000|ESRI shapefile|6668|Data City Sabae|
|sabae_aed_tokyo|ESRI shapefile|6668|Data City Sabae|
|sabae_light_rail|ESRI shapefile|6674|OpenStreetMap|
|sabae_rail|ESRI shapefile|6674|OpenStreetMap|
|sabae_way|ESRI shapefile|6674|OpenStreetMap|
