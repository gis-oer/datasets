# GIS-OER sample data(interpolation)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|fuji|GeoTIFF|6668|SRTM 1 Arc-Second Global|
