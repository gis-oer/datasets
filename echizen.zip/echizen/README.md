# GIS-OER sample data(Echizen)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|echizen_map|KMZ|4326|※1　越前市オープンデータ|
|flood_assumed_area|KML|4326|※1　越前市オープンデータ　浸水想定区域|
|refuge|KML|3857|※1　越前市オープンデータ　一次避難所|
|refuge|CSV||※1　越前市オープンデータ　一次避難所|
|flood_assumed_area|ESRI Shapefile|4326|※1　越前市オープンデータ　一次避難所|
|refuge_first|ESRI Shapefile|4326|※1　越前市オープンデータ　一次避難所|


> ※1[越前市オープンデータ](http://www.city.echizen.lg.jp/office/010/021/open-data-echizen.html)
