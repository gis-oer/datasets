# GIS-OER sample data(population)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|tokyo_23ku|ESRI shapefile|6677|area=OpenStreetMap|
|h27_population|CSV||東京都オープンデータ（平成27年国勢調査 人口等基本集計結果概要/ 第3表 区市町村、男女別人口及び世帯数(https://catalog.data.metro.tokyo.lg.jp/dataset/t000003d1700000002/resource/d51b7af4-0486-41bb-b5a6-c73f83d1ddf7))|
