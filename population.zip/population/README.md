# GIS-OER sample data(database)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|tokyo_23ku_population|ESRI shapefile|2451|area=OpenStreetMap, population=住民基本台帳による東京都の世帯と人口※1|

> [東京都の統計](http://www.toukei.metro.tokyo.jp/juukiy/jy-index.htm)
