# GIS-OER sample data(network)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|path|ESRI shapefile|2448|OpenStreetMap|
|hospital|ESRI shapefile|2448||
