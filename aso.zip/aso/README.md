# GIS-OER sample data(aso)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|aso_2kei|GeoTIFF|2444|SRTM 1 Arc-Second Global|
|aso_seismometers_100m_2kei|ESRI Shapefile|2444|※1|
|start|ESRI Shapefile|2444||
|end|ESRI Shapefile|2444||

> ※1 This data was created refer to the web page of Japan Meteorological Agency. https://www.data.jma.go.jp/svd/vois/data/fukuoka/503_Asosan/503_Obs_points.html
