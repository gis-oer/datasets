# GIS-OER sample data(fuji)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|fuji_1~12|GeoTIFF|6668|SRTM 1 Arc-Second Global|
|fuji_trails|GeoTIFF|6668|※1|
|land_condition|ESRI Shapefile|6668|※2|

> ※1 This data was created refer to OpenStreetMap
> ※2 This data was created refer to GSI ortho phot
