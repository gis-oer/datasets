# GIS-OER sample data(Tokyo)

|Name|Data_type|EPSG|Source|
|---|---|
|rail_9kei|ESRI shapefile|6677|OpenStreetMap|
|subway_9kei|ESRI shapefile|6677|OpenStreetMap|
|station_9kei|ESRI shapefile|6677|OpenStreetMap|
|way_9kei|ESRI shapefile|6677|OpenStreetMap|
|river_9kei|ESRI shapefile|6677|OpenStreetMap|
|post_office_9kei|ESRI shapefile|6677|OpenStreetMap|
|cvs_jgd2011_9|ESRI shapefile|6677|OpenStreetMap|
|tokyo_23ku_jgd2011_9|ESRI shapefile|6677|OpenStreetMap|
|post_office|CSV|4326|OpenStreetMap|
|tokyo_srtm|Geotiff|6677|SRTM 1 Arc-Second Global|
|gisoer_tiles|XML||https://github.com/MIERUNE/mierune-qgis |
