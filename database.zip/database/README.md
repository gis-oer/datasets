# GIS-OER sample data(database)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|tokyo|ESRI shapefile|2451|OpenStreetMap|
|station_9kei|ESRI shapefile|2451|OpenStreetMap|
