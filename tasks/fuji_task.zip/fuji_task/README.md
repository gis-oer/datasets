# GIS-OER sample data(fuji_task)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|fuji_2000_8|GeoTIFF|2450|SRTM 1 Arc-Second Global|
