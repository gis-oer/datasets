# GIS-OER sample data(sunayama)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|sunayama|GeoTIFF|3857|gis-oer|
