# GIS-OER sample data(tokyo23ku_cvs_jgd2000)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|tokyo23ku_cvs_jgd2000|ESRI shapefile|6677|OpenStreetMap|
