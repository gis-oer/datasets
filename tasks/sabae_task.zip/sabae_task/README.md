# GIS-OER sample data(sabae_task)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|sabae_006|jpeg||Data City Sabae（古地図006）|
|sabae_way|ESRI shapefile|6674|OpenStreetMap|
