# GIS-OER sample data(Taketomi)

|Name|Data_type|EPSG|Source|
|---|---|---|---|
|points|ESRI shapefile|6684|OpenStreetMap|
|road|ESRI shapefile|6684|OpenStreetMap|
|polygon|ESRI shapefile|6684|OpenStreetMap|
