# GIS-OER sample data(track)

This data was created using [Open GPX Tracker for iOS](http://www.merlos.org/iOS-Open-GPX-Tracker/).
